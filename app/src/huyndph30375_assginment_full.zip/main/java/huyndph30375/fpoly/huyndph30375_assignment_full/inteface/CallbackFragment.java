package huyndph30375.fpoly.huyndph30375_assignment_full.inteface;

public interface CallbackFragment {
    void changeFragment();
}
