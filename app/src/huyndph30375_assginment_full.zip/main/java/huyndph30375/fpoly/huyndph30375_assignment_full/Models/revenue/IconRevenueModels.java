package huyndph30375.fpoly.huyndph30375_assignment_full.Models.revenue;

public class IconRevenueModels {
    private int ImageIcon;

    public IconRevenueModels(int imageIcon) {
        ImageIcon = imageIcon;
    }

    public IconRevenueModels() {
    }

    public int getImageIcon() {
        return ImageIcon;
    }

    public void setImageIcon(int imageIcon) {
        ImageIcon = imageIcon;
    }
}
