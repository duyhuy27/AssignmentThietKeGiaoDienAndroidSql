package huyndph30375.fpoly.huyndph30375_assignment_full.Models.pay;

public class IconPayModels {
    private int imageIcon;

    public IconPayModels(int imageIcon) {
        this.imageIcon = imageIcon;
    }

    public IconPayModels() {
    }

    public int getImageIcon() {
        return imageIcon;
    }

    public void setImageIcon(int imageIcon) {
        this.imageIcon = imageIcon;
    }
}
